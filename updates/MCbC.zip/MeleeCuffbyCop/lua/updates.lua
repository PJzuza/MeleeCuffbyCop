if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'MeleeCuffbyCop',
		data = {
			modworkshop_id = 21693,
			dl_url = 'https://github.com/PJzuza/MeleeCuffbyCop/raw/master/updates/MCbC.zip',
			info_url = 'https://raw.githubusercontent.com/PJzuza/MeleeCuffbyCop/master/mod.txt'
		}
	})
end